<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "junky real estate";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the content type
header("Content-Type: application/json");

// Get the callback response
$stkCallbackResponse = file_get_contents('stkpush.php');

// Log the response
$logFile = "Mpesastkresponse.json";
$log = fopen($logFile, "a");
fwrite($log, $stkCallbackResponse);
fclose($log);

// Decode the callback response
$data = json_decode($stkCallbackResponse);

$MerchantRequestID = $data->Body->stkCallback->MerchantRequestID;
$CheckoutRequestID = $data->Body->stkCallback->CheckoutRequestID;
$ResultCode = $data->Body->stkCallback->ResultCode;
$ResultDesc = $data->Body->stkCallback->ResultDesc;
$Amount = $data->Body->stkCallback->CallbackMetadata->Item[0]->Value;
$TransactionId = $data->Body->stkCallback->CallbackMetadata->Item[1]->Value;
$UserPhoneNumber = $data->Body->stkCallback->CallbackMetadata->Item[4]->Value;

// Check if the transaction was successful
if ($ResultCode == 0) {
    // Store the transaction details in the database
    $sql = "INSERT INTO payment (MerchantRequestID, CheckoutRequestID, ResultCode, ResultDesc, Amount, TransactionId, UserPhoneNumber)
    VALUES ('$MerchantRequestID', '$CheckoutRequestID', '$ResultCode', '$ResultDesc', '$Amount', '$TransactionId', '$UserPhoneNumber')";

    if ($conn->query($sql) === TRUE) {
        echo "Transaction details stored successfully.";
    } else {
        echo "Error storing transaction details: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
