[10:15, 21/06/2023] Eugene Ambagwa: <?php
header("Content-Type: application/json");
$stkCallbackResponse = file_get_contents('php://input');
$logFile = "Mpesastkresponse.json";
$log = fopen($logFile, "a");
fwrite($log, $stkCallbackResponse);
fclose($log);

$data = json_decode($stkCallbackResponse);

$MerchantRequestID = $data->Body->stkCallback->MerchantRequestID;
$CheckoutRequestID = $data->Body->stkCallback->CheckoutRequestID;
$ResultCode = $data->Body->stkCallback->ResultCode;
$ResultDesc = $data->Body->stkCallback->ResultDesc;
$Amount = $data->Body->stkCallback->CallbackMetadata->Item[0]->Value;
$TransactionId = $data->Body->stkCallback->CallbackMetadata->Item[1]->Value;
$UserPhoneNumber = $data->Body->stkCallback->CallbackMetadata->Item[4]->Value;
//CHECK IF THE TRASACTION WAS SUCCESSFUL 
if ($ResultCode == 0) {
  //STORE THE TRANSACTION DETAILS IN THE DATABASE
[11:19, 21/06/2023] Eugene Ambagwa: <!DOCTYPE html>
<html>
<head>
    <title>Travel Form</title>
	<link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.19/css/intlTelInput.css"/>
	<script src="https://cdn.tutorialjinni.com/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/54f855da66.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php

        <div class="form">
        <form> 
            <method="POST" action="process.php">
            <div class="input-group">
            <input type="text" id="firstName" placeholder="First Name" required="required"><br><br>
        </div>
        <div class="input-group">
            <input type="text" id="lastName" placeholder="Last Name" required="required"><br><br>
        </div>
        <div class="input-group">
            <input type="number" id="age" placeholder="Age"  required="required"><br><br>
        </div>
        <div class="input-group">
            <input name="phone" type="text" id="phone" placeholder="Phone number" />
            
            <script>
                var input = document.querySelector("#phone");
                window.intlTelInput(input, {
                    separateDialCode: true,
                    excludeCountries: ["in", "il"],
                    preferredCountries: ["ru", "jp", "pk", "no"]
                });
            </script>
            <br><br>
        </div>
        <div class="input-group">
            <input type="number" id="associates" placeholder="Number of associates" required="required"><br><br>
        </div>
        <div class="input-group">
            <input type="text" id="duration" placeholder="Duration of stay" required="required">
        </div>
        <div class="input-group">
            <br><br>
            <label for="location">Desired Destination:</label>
            <select id="location" required="required">
                <option value="">Select Desired Destination</option>
                <option value="Nairobi National Park">Nairobi National Park</option>
                <option value="Maasai Mara National Reserve">Maasai Mara National Reserve</option>
            </select><br><br>
            </div>
            <button type="submit">SUBMIT <i class="fas fa-paper-plane"></i></button>
        </form>
        
    ?>
</body>
</html>